# wasm example template

Best place to start if you want to use wasm

## How to run

Make sure you have jandering engine where Cargo.toml can pick it up!

    wasm-pack build --target web
